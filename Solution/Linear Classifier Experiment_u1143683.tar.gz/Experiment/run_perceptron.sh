python3.6 run_perceptron.py
